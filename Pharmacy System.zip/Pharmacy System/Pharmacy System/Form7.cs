using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient ;
namespace databaseC
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connecrionstring = "Initial Catalog=medical;Data Source=.;Integrated Security=true";

            SqlConnection con = new SqlConnection(connecrionstring);
            SqlCommand cm = new SqlCommand();
              ///// SqlDataAdapter da2 = new SqlDataAdapter("Select * from stockpurchase where [Batch No]='" + txtbat.Text + "'", con);
           
            DataSet ds2 = new DataSet();
      ////      da2.Fill(ds2);
            //crystalReportViewer1.RefreshReport();
             //Form8 jform = new Form8();
            // jform.ShowDialog();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            //dateTimePicker1.Format.ToString ( DateTime.Now.Date.ToString("dd-MM-yy"));
        }

        private void Form7_Load(object sender, EventArgs e)
        {
            string date;
            date = DateTime.Now.ToLongTimeString();
         //  textBox1.Text = date.ToString();
          // MessageBox.Show(date.ToString());
        }

        private void button2_Click(object sender, EventArgs e)
        {
           // try
           // {
                int len;
                len = textBox1.Text.Length;
                MessageBox.Show(len.ToString());


               string s = (textBox1.Text);
               MessageBox.Show(s.ToString());

                while (len > 1)
                {
                   // int  i;
                  string  s1  =Mid(s,len);
                    if (s1 == ".")
                    {
                        MessageBox.Show(s1 );  
                    }
                    len--;

                }
             
            
            
           // }
           // catch (Exception ex)
          //  {
          //      MessageBox.Show(ex.Message);
         //   }
        }
       /* public string Mid(int length)
        {
            string s = "Hello";
            
            MessageBox.Show(s);
           return s;
          MessageBox.Show(s);
          
            
          //  string s1 = s.Left(3);
         //   string s2 = s.Right(3);
         //   string s3 = s.Mid(2, 2);
         //   string s4 = s.Mid(3);
          //  MessageBox.Show("s: " + s + "\n" + "s1: " + s1 + "\n" + "s2: " + s2 + "\n" + "s3: " + s3 + "\n" + "s4: " + s4 + "\n");
        }*/
        public string Mid( string text,int start)
        {
            return text.Substring (start);
            //MessageBox.Show(text.Substring(start, num));
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int x;
            string s = textBox1.Text;
            x = s.LastIndexOf(".");
            string ss = s.Substring(0, x + 3);
            textBox1.Text = ss;
        }
     //  public string Mid1(string  text1, int start1)
      //  {
      //    return text1.Substring(start1,start1);
      //  }
    
    }
}