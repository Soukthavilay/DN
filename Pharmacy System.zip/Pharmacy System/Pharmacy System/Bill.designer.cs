namespace databaseC
{
    partial class Bill
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtpri = new System.Windows.Forms.TextBox();
            this.txtqty = new System.Windows.Forms.TextBox();
            this.txtmfc = new System.Windows.Forms.TextBox();
            this.txtbat = new System.Windows.Forms.TextBox();
            this.txtloc = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtamt = new System.Windows.Forms.TextBox();
            this.dataGrid1 = new System.Windows.Forms.DataGrid();
            this.txttaxper = new System.Windows.Forms.TextBox();
            this.txttaxamt = new System.Windows.Forms.TextBox();
            this.amt = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtbill = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.txtmed = new System.Windows.Forms.TextBox();
            this.txtexp = new System.Windows.Forms.TextBox();
            this.date = new System.Windows.Forms.Label();
            this.CrystalReport11 = new databaseC.CrystalReport1();
            this.crystalReportViewer1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.CrystalReport21 = new databaseC.CrystalReport2();
            this.time = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.panelTOP = new System.Windows.Forms.Panel();
            this.Label16 = new System.Windows.Forms.Label();
            this.picTOP_LEFT_02 = new System.Windows.Forms.PictureBox();
            this.picTOP_LEFT_01 = new System.Windows.Forms.PictureBox();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.panelBOTTOM = new System.Windows.Forms.Panel();
            this.picBOTTOM_LEFT = new System.Windows.Forms.PictureBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).BeginInit();
            this.panelTOP.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picTOP_LEFT_02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picTOP_LEFT_01)).BeginInit();
            this.panelBOTTOM.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBOTTOM_LEFT)).BeginInit();
            this.SuspendLayout();
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Georgia", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(399, 93);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(69, 15);
            this.label8.TabIndex = 14;
            this.label8.Text = "Unit Price";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Georgia", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(563, 93);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(63, 15);
            this.label7.TabIndex = 13;
            this.label7.Text = "Quantity";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Georgia", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(314, 93);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 15);
            this.label6.TabIndex = 12;
            this.label6.Text = "Expiry Date";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Georgia", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(23, 93);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 15);
            this.label4.TabIndex = 10;
            this.label4.Text = "Batch No.";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Georgia", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(243, 93);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 15);
            this.label3.TabIndex = 9;
            this.label3.Text = "MFC";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Georgia", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(111, 93);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 15);
            this.label2.TabIndex = 8;
            this.label2.Text = "Medicine Name";
            // 
            // txtpri
            // 
            this.txtpri.Font = new System.Drawing.Font("Georgia", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpri.Location = new System.Drawing.Point(402, 130);
            this.txtpri.Name = "txtpri";
            this.txtpri.Size = new System.Drawing.Size(61, 21);
            this.txtpri.TabIndex = 29;
            // 
            // txtqty
            // 
            this.txtqty.Font = new System.Drawing.Font("Georgia", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtqty.Location = new System.Drawing.Point(556, 129);
            this.txtqty.Name = "txtqty";
            this.txtqty.Size = new System.Drawing.Size(68, 21);
            this.txtqty.TabIndex = 28;
            this.txtqty.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtqty_KeyDown);
            // 
            // txtmfc
            // 
            this.txtmfc.Font = new System.Drawing.Font("Georgia", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmfc.Location = new System.Drawing.Point(230, 128);
            this.txtmfc.Name = "txtmfc";
            this.txtmfc.Size = new System.Drawing.Size(88, 21);
            this.txtmfc.TabIndex = 26;
            // 
            // txtbat
            // 
            this.txtbat.Font = new System.Drawing.Font("Georgia", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbat.Location = new System.Drawing.Point(7, 127);
            this.txtbat.Name = "txtbat";
            this.txtbat.Size = new System.Drawing.Size(87, 21);
            this.txtbat.TabIndex = 25;
            this.txtbat.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtbat_KeyDown);
            // 
            // txtloc
            // 
            this.txtloc.Font = new System.Drawing.Font("Georgia", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtloc.Location = new System.Drawing.Point(469, 130);
            this.txtloc.Name = "txtloc";
            this.txtloc.Size = new System.Drawing.Size(81, 21);
            this.txtloc.TabIndex = 48;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Georgia", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(476, 93);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(59, 15);
            this.label17.TabIndex = 47;
            this.label17.Text = "Locaton";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Georgia", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(637, 93);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 15);
            this.label1.TabIndex = 49;
            this.label1.Text = "Amount";
            // 
            // txtamt
            // 
            this.txtamt.Font = new System.Drawing.Font("Georgia", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtamt.Location = new System.Drawing.Point(630, 129);
            this.txtamt.Name = "txtamt";
            this.txtamt.Size = new System.Drawing.Size(100, 21);
            this.txtamt.TabIndex = 50;
            // 
            // dataGrid1
            // 
            this.dataGrid1.AlternatingBackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.dataGrid1.BackColor = System.Drawing.Color.White;
            this.dataGrid1.BackgroundColor = System.Drawing.Color.LightGoldenrodYellow;
            this.dataGrid1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.dataGrid1.CaptionBackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.dataGrid1.CaptionFont = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.dataGrid1.CaptionForeColor = System.Drawing.Color.DarkSlateBlue;
            this.dataGrid1.DataMember = "";
            this.dataGrid1.FlatMode = true;
            this.dataGrid1.Font = new System.Drawing.Font("Tahoma", 8F);
            this.dataGrid1.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.dataGrid1.GridLineColor = System.Drawing.Color.Peru;
            this.dataGrid1.GridLineStyle = System.Windows.Forms.DataGridLineStyle.None;
            this.dataGrid1.HeaderBackColor = System.Drawing.Color.Maroon;
            this.dataGrid1.HeaderFont = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.dataGrid1.HeaderForeColor = System.Drawing.Color.LightGoldenrodYellow;
            this.dataGrid1.LinkColor = System.Drawing.Color.Maroon;
            this.dataGrid1.Location = new System.Drawing.Point(-2, 165);
            this.dataGrid1.Name = "dataGrid1";
            this.dataGrid1.ParentRowsBackColor = System.Drawing.Color.BurlyWood;
            this.dataGrid1.ParentRowsForeColor = System.Drawing.Color.DarkSlateBlue;
            this.dataGrid1.RowHeadersVisible = false;
            this.dataGrid1.SelectionBackColor = System.Drawing.Color.DarkSlateBlue;
            this.dataGrid1.SelectionForeColor = System.Drawing.Color.GhostWhite;
            this.dataGrid1.Size = new System.Drawing.Size(718, 454);
            this.dataGrid1.TabIndex = 51;
            // 
            // txttaxper
            // 
            this.txttaxper.Location = new System.Drawing.Point(265, 693);
            this.txttaxper.Name = "txttaxper";
            this.txttaxper.Size = new System.Drawing.Size(100, 20);
            this.txttaxper.TabIndex = 53;
            this.txttaxper.Visible = false;
            // 
            // txttaxamt
            // 
            this.txttaxamt.Location = new System.Drawing.Point(402, 693);
            this.txttaxamt.Name = "txttaxamt";
            this.txttaxamt.Size = new System.Drawing.Size(100, 20);
            this.txttaxamt.TabIndex = 52;
            this.txttaxamt.Visible = false;
            // 
            // amt
            // 
            this.amt.Location = new System.Drawing.Point(916, 637);
            this.amt.Name = "amt";
            this.amt.Size = new System.Drawing.Size(100, 20);
            this.amt.TabIndex = 57;
            this.amt.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Georgia", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(740, 109);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(39, 15);
            this.label5.TabIndex = 60;
            this.label5.Text = "Time";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Georgia", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(740, 136);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(37, 15);
            this.label9.TabIndex = 61;
            this.label9.Text = "Date";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Georgia", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(740, 81);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(49, 15);
            this.label10.TabIndex = 63;
            this.label10.Text = "Bill No";
            // 
            // txtbill
            // 
            this.txtbill.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtbill.Font = new System.Drawing.Font("Georgia", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbill.Location = new System.Drawing.Point(795, 81);
            this.txtbill.Name = "txtbill";
            this.txtbill.ReadOnly = true;
            this.txtbill.Size = new System.Drawing.Size(97, 14);
            this.txtbill.TabIndex = 64;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // txtmed
            // 
            this.txtmed.Font = new System.Drawing.Font("Georgia", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmed.Location = new System.Drawing.Point(100, 127);
            this.txtmed.Name = "txtmed";
            this.txtmed.Size = new System.Drawing.Size(124, 21);
            this.txtmed.TabIndex = 66;
            // 
            // txtexp
            // 
            this.txtexp.Font = new System.Drawing.Font("Georgia", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtexp.Location = new System.Drawing.Point(324, 129);
            this.txtexp.Name = "txtexp";
            this.txtexp.Size = new System.Drawing.Size(72, 21);
            this.txtexp.TabIndex = 68;
            // 
            // date
            // 
            this.date.Font = new System.Drawing.Font("Georgia", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.date.Location = new System.Drawing.Point(792, 133);
            this.date.Name = "date";
            this.date.Size = new System.Drawing.Size(100, 23);
            this.date.TabIndex = 69;
            // 
            // crystalReportViewer1
            // 
            this.crystalReportViewer1.ActiveViewIndex = 0;
            this.crystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.crystalReportViewer1.DisplayGroupTree = false;
            this.crystalReportViewer1.DisplayStatusBar = false;
            this.crystalReportViewer1.Location = new System.Drawing.Point(722, 165);
            this.crystalReportViewer1.Name = "crystalReportViewer1";
            this.crystalReportViewer1.ReportSource = this.CrystalReport21;
            this.crystalReportViewer1.Size = new System.Drawing.Size(310, 454);
            this.crystalReportViewer1.TabIndex = 67;
            // 
            // time
            // 
            this.time.Font = new System.Drawing.Font("Georgia", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.time.Location = new System.Drawing.Point(792, 109);
            this.time.Name = "time";
            this.time.Size = new System.Drawing.Size(100, 23);
            this.time.TabIndex = 70;
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("Georgia", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.PaleGreen;
            this.label11.Location = new System.Drawing.Point(743, 626);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(273, 67);
            this.label11.TabIndex = 71;
            // 
            // panelTOP
            // 
            this.panelTOP.BackgroundImage = global::databaseC.Properties.Resources.payroll_03;
            this.panelTOP.Controls.Add(this.Label16);
            this.panelTOP.Controls.Add(this.picTOP_LEFT_02);
            this.panelTOP.Controls.Add(this.picTOP_LEFT_01);
            this.panelTOP.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTOP.Location = new System.Drawing.Point(0, 0);
            this.panelTOP.Name = "panelTOP";
            this.panelTOP.Size = new System.Drawing.Size(1028, 78);
            this.panelTOP.TabIndex = 72;
            // 
            // Label16
            // 
            this.Label16.BackColor = System.Drawing.Color.LightSkyBlue;
            this.Label16.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label16.Location = new System.Drawing.Point(156, 21);
            this.Label16.Name = "Label16";
            this.Label16.Size = new System.Drawing.Size(870, 26);
            this.Label16.TabIndex = 2;
            this.Label16.Text = "Medical Management System";
            // 
            // picTOP_LEFT_02
            // 
            this.picTOP_LEFT_02.Dock = System.Windows.Forms.DockStyle.Left;
            this.picTOP_LEFT_02.Image = global::databaseC.Properties.Resources.payroll_03;
            this.picTOP_LEFT_02.Location = new System.Drawing.Point(156, 0);
            this.picTOP_LEFT_02.Name = "picTOP_LEFT_02";
            this.picTOP_LEFT_02.Size = new System.Drawing.Size(302, 78);
            this.picTOP_LEFT_02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picTOP_LEFT_02.TabIndex = 1;
            this.picTOP_LEFT_02.TabStop = false;
            // 
            // picTOP_LEFT_01
            // 
            this.picTOP_LEFT_01.Dock = System.Windows.Forms.DockStyle.Left;
            this.picTOP_LEFT_01.Image = global::databaseC.Properties.Resources.payroll_01;
            this.picTOP_LEFT_01.Location = new System.Drawing.Point(0, 0);
            this.picTOP_LEFT_01.Name = "picTOP_LEFT_01";
            this.picTOP_LEFT_01.Size = new System.Drawing.Size(156, 78);
            this.picTOP_LEFT_01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picTOP_LEFT_01.TabIndex = 0;
            this.picTOP_LEFT_01.TabStop = false;
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("Georgia", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Image = global::databaseC.Properties.Resources.Important_Files;
            this.button5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button5.Location = new System.Drawing.Point(378, 630);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(110, 52);
            this.button5.TabIndex = 65;
            this.button5.Text = "&New Bill";
            this.button5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Georgia", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Image = global::databaseC.Properties.Resources.Print;
            this.button4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button4.Location = new System.Drawing.Point(494, 631);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(109, 51);
            this.button4.TabIndex = 62;
            this.button4.Text = "&Print";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Georgia", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Image = global::databaseC.Properties.Resources.INFO;
            this.button3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.Location = new System.Drawing.Point(609, 631);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(117, 53);
            this.button3.TabIndex = 56;
            this.button3.Text = "&Total Amount";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Georgia", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Image = global::databaseC.Properties.Resources.Recycle_Bin_Empty;
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.Location = new System.Drawing.Point(265, 630);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(107, 51);
            this.button2.TabIndex = 55;
            this.button2.Text = "&Remove Medicine";
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // panelBOTTOM
            // 
            this.panelBOTTOM.BackgroundImage = global::databaseC.Properties.Resources.payroll_03;
            this.panelBOTTOM.Controls.Add(this.picBOTTOM_LEFT);
            this.panelBOTTOM.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelBOTTOM.Location = new System.Drawing.Point(0, 719);
            this.panelBOTTOM.Name = "panelBOTTOM";
            this.panelBOTTOM.Size = new System.Drawing.Size(1028, 27);
            this.panelBOTTOM.TabIndex = 73;
            // 
            // picBOTTOM_LEFT
            // 
            this.picBOTTOM_LEFT.Dock = System.Windows.Forms.DockStyle.Left;
            this.picBOTTOM_LEFT.Image = global::databaseC.Properties.Resources.payroll_03;
            this.picBOTTOM_LEFT.Location = new System.Drawing.Point(0, 0);
            this.picBOTTOM_LEFT.Name = "picBOTTOM_LEFT";
            this.picBOTTOM_LEFT.Size = new System.Drawing.Size(302, 27);
            this.picBOTTOM_LEFT.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picBOTTOM_LEFT.TabIndex = 1;
            this.picBOTTOM_LEFT.TabStop = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Georgia", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(23, 638);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(73, 16);
            this.label12.TabIndex = 74;
            this.label12.Text = "F11-Print";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Georgia", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(23, 668);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(97, 16);
            this.label13.TabIndex = 75;
            this.label13.Text = "F12-New Bill";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Georgia", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(126, 668);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(108, 16);
            this.label14.TabIndex = 76;
            this.label14.Text = "F9-Calculator";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Georgia", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(126, 637);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(98, 16);
            this.label15.TabIndex = 77;
            this.label15.Text = "F10-Remove";
            // 
            // Bill
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1028, 746);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.panelBOTTOM);
            this.Controls.Add(this.panelTOP);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.time);
            this.Controls.Add(this.date);
            this.Controls.Add(this.txtexp);
            this.Controls.Add(this.crystalReportViewer1);
            this.Controls.Add(this.txtmed);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.txtbill);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.amt);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.txttaxper);
            this.Controls.Add(this.txttaxamt);
            this.Controls.Add(this.dataGrid1);
            this.Controls.Add(this.txtamt);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtloc);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.txtpri);
            this.Controls.Add(this.txtqty);
            this.Controls.Add(this.txtmfc);
            this.Controls.Add(this.txtbat);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Name = "Bill";
            this.Text = "Bill";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).EndInit();
            this.panelTOP.ResumeLayout(false);
            this.panelTOP.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picTOP_LEFT_02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picTOP_LEFT_01)).EndInit();
            this.panelBOTTOM.ResumeLayout(false);
            this.panelBOTTOM.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBOTTOM_LEFT)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtpri;
        private System.Windows.Forms.TextBox txtqty;
        private System.Windows.Forms.TextBox txtmfc;
        private System.Windows.Forms.TextBox txtbat;
        private System.Windows.Forms.TextBox txtloc;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtamt;
        private System.Windows.Forms.DataGrid dataGrid1;
        private System.Windows.Forms.TextBox txttaxper;
        private System.Windows.Forms.TextBox txttaxamt;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox amt;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtbill;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TextBox txtmed;
        private CrystalDecisions.Windows.Forms.CrystalReportViewer crystalReportViewer1;
        private CrystalReport1 CrystalReport11;
        private CrystalReport2 CrystalReport21;
        private System.Windows.Forms.TextBox txtexp;
        private System.Windows.Forms.Label date;
        private System.Windows.Forms.Label time;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panelTOP;
        internal System.Windows.Forms.Label Label16;
        private System.Windows.Forms.PictureBox picTOP_LEFT_02;
        private System.Windows.Forms.PictureBox picTOP_LEFT_01;
        private System.Windows.Forms.Panel panelBOTTOM;
        private System.Windows.Forms.PictureBox picBOTTOM_LEFT;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
    }
}