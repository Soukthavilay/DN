using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace databaseC
{
    public partial class Purchasereport : Form
    {
        public Purchasereport()
        {
            InitializeComponent();
        }

        private void Form8_Load(object sender, EventArgs e)
        {
            crystalReportViewer1.RefreshReport();
        }
    }
}