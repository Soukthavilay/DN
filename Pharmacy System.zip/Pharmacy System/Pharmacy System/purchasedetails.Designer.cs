namespace databaseC
{
    partial class purchasedetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGrid1 = new System.Windows.Forms.DataGrid();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.panelTOP = new System.Windows.Forms.Panel();
            this.label20 = new System.Windows.Forms.Label();
            this.picTOP_LEFT_02 = new System.Windows.Forms.PictureBox();
            this.picTOP_LEFT_01 = new System.Windows.Forms.PictureBox();
            this.panelBOTTOM = new System.Windows.Forms.Panel();
            this.picBOTTOM_LEFT = new System.Windows.Forms.PictureBox();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).BeginInit();
            this.panelTOP.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picTOP_LEFT_02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picTOP_LEFT_01)).BeginInit();
            this.panelBOTTOM.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBOTTOM_LEFT)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGrid1
            // 
            this.dataGrid1.AlternatingBackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.dataGrid1.BackColor = System.Drawing.Color.White;
            this.dataGrid1.BackgroundColor = System.Drawing.Color.LightGoldenrodYellow;
            this.dataGrid1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.dataGrid1.CaptionBackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.dataGrid1.CaptionFont = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.dataGrid1.CaptionForeColor = System.Drawing.Color.DarkSlateBlue;
            this.dataGrid1.DataMember = "";
            this.dataGrid1.FlatMode = true;
            this.dataGrid1.Font = new System.Drawing.Font("Tahoma", 8F);
            this.dataGrid1.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.dataGrid1.GridLineColor = System.Drawing.Color.Peru;
            this.dataGrid1.GridLineStyle = System.Windows.Forms.DataGridLineStyle.None;
            this.dataGrid1.HeaderBackColor = System.Drawing.Color.Maroon;
            this.dataGrid1.HeaderFont = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.dataGrid1.HeaderForeColor = System.Drawing.Color.LightGoldenrodYellow;
            this.dataGrid1.LinkColor = System.Drawing.Color.Maroon;
            this.dataGrid1.Location = new System.Drawing.Point(216, 96);
            this.dataGrid1.Name = "dataGrid1";
            this.dataGrid1.ParentRowsBackColor = System.Drawing.Color.BurlyWood;
            this.dataGrid1.ParentRowsForeColor = System.Drawing.Color.DarkSlateBlue;
            this.dataGrid1.RowHeadersVisible = false;
            this.dataGrid1.SelectionBackColor = System.Drawing.Color.DarkSlateBlue;
            this.dataGrid1.SelectionForeColor = System.Drawing.Color.GhostWhite;
            this.dataGrid1.Size = new System.Drawing.Size(789, 559);
            this.dataGrid1.TabIndex = 52;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Georgia", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Image = global::databaseC.Properties.Resources.Find_3;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label1.Location = new System.Drawing.Point(0, 163);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 31);
            this.label1.TabIndex = 56;
            this.label1.Text = "Find";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Georgia", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(67, 167);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(143, 22);
            this.textBox1.TabIndex = 55;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // panelTOP
            // 
            this.panelTOP.BackgroundImage = global::databaseC.Properties.Resources.payroll_03;
            this.panelTOP.Controls.Add(this.label20);
            this.panelTOP.Controls.Add(this.picTOP_LEFT_02);
            this.panelTOP.Controls.Add(this.picTOP_LEFT_01);
            this.panelTOP.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTOP.Location = new System.Drawing.Point(0, 0);
            this.panelTOP.Name = "panelTOP";
            this.panelTOP.Size = new System.Drawing.Size(1028, 78);
            this.panelTOP.TabIndex = 76;
            // 
            // label20
            // 
            this.label20.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label20.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(156, 21);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(870, 26);
            this.label20.TabIndex = 2;
            this.label20.Text = "Purchase Details";
            // 
            // picTOP_LEFT_02
            // 
            this.picTOP_LEFT_02.Dock = System.Windows.Forms.DockStyle.Left;
            this.picTOP_LEFT_02.Image = global::databaseC.Properties.Resources.payroll_03;
            this.picTOP_LEFT_02.Location = new System.Drawing.Point(156, 0);
            this.picTOP_LEFT_02.Name = "picTOP_LEFT_02";
            this.picTOP_LEFT_02.Size = new System.Drawing.Size(302, 78);
            this.picTOP_LEFT_02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picTOP_LEFT_02.TabIndex = 1;
            this.picTOP_LEFT_02.TabStop = false;
            // 
            // picTOP_LEFT_01
            // 
            this.picTOP_LEFT_01.Dock = System.Windows.Forms.DockStyle.Left;
            this.picTOP_LEFT_01.Image = global::databaseC.Properties.Resources.payroll_01;
            this.picTOP_LEFT_01.Location = new System.Drawing.Point(0, 0);
            this.picTOP_LEFT_01.Name = "picTOP_LEFT_01";
            this.picTOP_LEFT_01.Size = new System.Drawing.Size(156, 78);
            this.picTOP_LEFT_01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picTOP_LEFT_01.TabIndex = 0;
            this.picTOP_LEFT_01.TabStop = false;
            // 
            // panelBOTTOM
            // 
            this.panelBOTTOM.BackgroundImage = global::databaseC.Properties.Resources.payroll_03;
            this.panelBOTTOM.Controls.Add(this.picBOTTOM_LEFT);
            this.panelBOTTOM.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelBOTTOM.Location = new System.Drawing.Point(0, 702);
            this.panelBOTTOM.Name = "panelBOTTOM";
            this.panelBOTTOM.Size = new System.Drawing.Size(1028, 44);
            this.panelBOTTOM.TabIndex = 84;
            // 
            // picBOTTOM_LEFT
            // 
            this.picBOTTOM_LEFT.Dock = System.Windows.Forms.DockStyle.Left;
            this.picBOTTOM_LEFT.Image = global::databaseC.Properties.Resources.payroll_03;
            this.picBOTTOM_LEFT.Location = new System.Drawing.Point(0, 0);
            this.picBOTTOM_LEFT.Name = "picBOTTOM_LEFT";
            this.picBOTTOM_LEFT.Size = new System.Drawing.Size(302, 44);
            this.picBOTTOM_LEFT.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picBOTTOM_LEFT.TabIndex = 1;
            this.picBOTTOM_LEFT.TabStop = false;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Georgia", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Image = global::databaseC.Properties.Resources.Delete_2;
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.Location = new System.Drawing.Point(46, 324);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(91, 44);
            this.button2.TabIndex = 85;
            this.button2.Text = "Delete All";
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // purchasedetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1028, 746);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.panelBOTTOM);
            this.Controls.Add(this.panelTOP);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.dataGrid1);
            this.Name = "purchasedetails";
            this.Text = "purchasedetails";
            this.Load += new System.EventHandler(this.purchasedetails_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).EndInit();
            this.panelTOP.ResumeLayout(false);
            this.panelTOP.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picTOP_LEFT_02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picTOP_LEFT_01)).EndInit();
            this.panelBOTTOM.ResumeLayout(false);
            this.panelBOTTOM.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBOTTOM_LEFT)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGrid dataGrid1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Panel panelTOP;
        internal System.Windows.Forms.Label label20;
        private System.Windows.Forms.PictureBox picTOP_LEFT_02;
        private System.Windows.Forms.PictureBox picTOP_LEFT_01;
        private System.Windows.Forms.Panel panelBOTTOM;
        private System.Windows.Forms.PictureBox picBOTTOM_LEFT;
        private System.Windows.Forms.Button button2;
    }
}