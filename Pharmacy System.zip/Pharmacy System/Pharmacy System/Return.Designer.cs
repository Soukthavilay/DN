namespace databaseC
{
    partial class Return
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.Purchase = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtqty = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txttotamt = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtuni = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txttaxper = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txttaxamt = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtpri = new System.Windows.Forms.TextBox();
            this.txtstock = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtbat = new System.Windows.Forms.TextBox();
            this.txtmfc = new System.Windows.Forms.TextBox();
            this.txtmed = new System.Windows.Forms.TextBox();
            this.txtin = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.date123 = new System.Windows.Forms.Label();
            this.date = new System.Windows.Forms.Label();
            this.dataGrid1 = new System.Windows.Forms.DataGrid();
            this.button1 = new System.Windows.Forms.Button();
            this.panelBOTTOM = new System.Windows.Forms.Panel();
            this.picBOTTOM_LEFT = new System.Windows.Forms.PictureBox();
            this.panelTOP = new System.Windows.Forms.Panel();
            this.label20 = new System.Windows.Forms.Label();
            this.picTOP_LEFT_02 = new System.Windows.Forms.PictureBox();
            this.picTOP_LEFT_01 = new System.Windows.Forms.PictureBox();
            this.button10 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.Purchase.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).BeginInit();
            this.panelBOTTOM.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBOTTOM_LEFT)).BeginInit();
            this.panelTOP.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picTOP_LEFT_02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picTOP_LEFT_01)).BeginInit();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Georgia", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(320, 572);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 22);
            this.textBox1.TabIndex = 73;
            this.textBox1.Visible = false;
            // 
            // Purchase
            // 
            this.Purchase.Controls.Add(this.label7);
            this.Purchase.Controls.Add(this.txtqty);
            this.Purchase.Controls.Add(this.label8);
            this.Purchase.Controls.Add(this.txttotamt);
            this.Purchase.Controls.Add(this.label13);
            this.Purchase.Controls.Add(this.txtuni);
            this.Purchase.Controls.Add(this.label9);
            this.Purchase.Controls.Add(this.txttaxper);
            this.Purchase.Controls.Add(this.label12);
            this.Purchase.Controls.Add(this.txttaxamt);
            this.Purchase.Controls.Add(this.label11);
            this.Purchase.Font = new System.Drawing.Font("Georgia", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Purchase.Location = new System.Drawing.Point(26, 296);
            this.Purchase.Name = "Purchase";
            this.Purchase.Size = new System.Drawing.Size(245, 264);
            this.Purchase.TabIndex = 68;
            this.Purchase.TabStop = false;
            this.Purchase.Text = "Return";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(15, 25);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(75, 16);
            this.label7.TabIndex = 6;
            this.label7.Text = "Quantity";
            // 
            // txtqty
            // 
            this.txtqty.Location = new System.Drawing.Point(116, 25);
            this.txtqty.Name = "txtqty";
            this.txtqty.Size = new System.Drawing.Size(100, 22);
            this.txtqty.TabIndex = 14;
            this.txtqty.Text = "0";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Enabled = false;
            this.label8.Location = new System.Drawing.Point(15, 68);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(80, 16);
            this.label8.TabIndex = 7;
            this.label8.Text = "Unit Price";
            // 
            // txttotamt
            // 
            this.txttotamt.Location = new System.Drawing.Point(116, 210);
            this.txttotamt.Name = "txttotamt";
            this.txttotamt.Size = new System.Drawing.Size(100, 22);
            this.txttotamt.TabIndex = 28;
            this.txttotamt.Text = "0";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(12, 213);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(100, 16);
            this.label13.TabIndex = 33;
            this.label13.Text = "Total Amont";
            // 
            // txtuni
            // 
            this.txtuni.Enabled = false;
            this.txtuni.Location = new System.Drawing.Point(116, 65);
            this.txtuni.Name = "txtuni";
            this.txtuni.Size = new System.Drawing.Size(100, 22);
            this.txtuni.TabIndex = 15;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Enabled = false;
            this.label9.Location = new System.Drawing.Point(12, 108);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(65, 16);
            this.label9.TabIndex = 25;
            this.label9.Text = "VATTax";
            // 
            // txttaxper
            // 
            this.txttaxper.Enabled = false;
            this.txttaxper.Location = new System.Drawing.Point(116, 108);
            this.txttaxper.Name = "txttaxper";
            this.txttaxper.Size = new System.Drawing.Size(100, 22);
            this.txttaxper.TabIndex = 26;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Enabled = false;
            this.label12.Location = new System.Drawing.Point(12, 165);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(98, 16);
            this.label12.TabIndex = 32;
            this.label12.Text = "Tax Amount";
            // 
            // txttaxamt
            // 
            this.txttaxamt.Enabled = false;
            this.txttaxamt.Location = new System.Drawing.Point(116, 165);
            this.txttaxamt.Name = "txttaxamt";
            this.txttaxamt.Size = new System.Drawing.Size(100, 22);
            this.txttaxamt.TabIndex = 17;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Enabled = false;
            this.label11.Location = new System.Drawing.Point(129, 133);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(110, 16);
            this.label11.TabIndex = 31;
            this.label11.Text = "In Percentage";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Georgia", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(34, 273);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(40, 16);
            this.label10.TabIndex = 30;
            this.label10.Text = "MRP";
            // 
            // txtpri
            // 
            this.txtpri.Font = new System.Drawing.Font("Georgia", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpri.Location = new System.Drawing.Point(153, 270);
            this.txtpri.Name = "txtpri";
            this.txtpri.Size = new System.Drawing.Size(100, 22);
            this.txtpri.TabIndex = 29;
            // 
            // txtstock
            // 
            this.txtstock.Font = new System.Drawing.Font("Georgia", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtstock.Location = new System.Drawing.Point(381, 140);
            this.txtstock.Name = "txtstock";
            this.txtstock.ReadOnly = true;
            this.txtstock.Size = new System.Drawing.Size(120, 22);
            this.txtstock.TabIndex = 65;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Georgia", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(254, 143);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(109, 16);
            this.label14.TabIndex = 64;
            this.label14.Text = "Current Stock";
            // 
            // txtbat
            // 
            this.txtbat.Font = new System.Drawing.Font("Georgia", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbat.Location = new System.Drawing.Point(153, 140);
            this.txtbat.Name = "txtbat";
            this.txtbat.Size = new System.Drawing.Size(100, 22);
            this.txtbat.TabIndex = 62;
            this.txtbat.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtbat_KeyDown);
            // 
            // txtmfc
            // 
            this.txtmfc.Font = new System.Drawing.Font("Georgia", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmfc.Location = new System.Drawing.Point(153, 235);
            this.txtmfc.Name = "txtmfc";
            this.txtmfc.Size = new System.Drawing.Size(129, 22);
            this.txtmfc.TabIndex = 61;
            // 
            // txtmed
            // 
            this.txtmed.Font = new System.Drawing.Font("Georgia", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmed.Location = new System.Drawing.Point(154, 196);
            this.txtmed.Name = "txtmed";
            this.txtmed.Size = new System.Drawing.Size(180, 22);
            this.txtmed.TabIndex = 60;
            // 
            // txtin
            // 
            this.txtin.Font = new System.Drawing.Font("Georgia", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtin.Location = new System.Drawing.Point(153, 92);
            this.txtin.Name = "txtin";
            this.txtin.Size = new System.Drawing.Size(100, 22);
            this.txtin.TabIndex = 59;
            this.txtin.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtin_KeyDown);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Georgia", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(34, 143);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 16);
            this.label4.TabIndex = 57;
            this.label4.Text = "Batch No.";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Georgia", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(34, 238);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 16);
            this.label3.TabIndex = 56;
            this.label3.Text = "MFC";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Georgia", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(34, 199);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 16);
            this.label2.TabIndex = 55;
            this.label2.Text = "Medicine Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Georgia", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(34, 92);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 16);
            this.label1.TabIndex = 54;
            this.label1.Text = "Invoice No";
            // 
            // date123
            // 
            this.date123.Font = new System.Drawing.Font("Georgia", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.date123.Location = new System.Drawing.Point(259, 99);
            this.date123.Name = "date123";
            this.date123.Size = new System.Drawing.Size(88, 23);
            this.date123.TabIndex = 79;
            this.date123.Text = "Date";
            // 
            // date
            // 
            this.date.Font = new System.Drawing.Font("Georgia", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.date.Location = new System.Drawing.Point(378, 99);
            this.date.Name = "date";
            this.date.Size = new System.Drawing.Size(100, 23);
            this.date.TabIndex = 80;
            // 
            // dataGrid1
            // 
            this.dataGrid1.AlternatingBackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.dataGrid1.BackColor = System.Drawing.Color.White;
            this.dataGrid1.BackgroundColor = System.Drawing.Color.LightGoldenrodYellow;
            this.dataGrid1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.dataGrid1.CaptionBackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.dataGrid1.CaptionFont = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.dataGrid1.CaptionForeColor = System.Drawing.Color.DarkSlateBlue;
            this.dataGrid1.DataMember = "";
            this.dataGrid1.FlatMode = true;
            this.dataGrid1.Font = new System.Drawing.Font("Tahoma", 8F);
            this.dataGrid1.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.dataGrid1.GridLineColor = System.Drawing.Color.Peru;
            this.dataGrid1.GridLineStyle = System.Windows.Forms.DataGridLineStyle.None;
            this.dataGrid1.HeaderBackColor = System.Drawing.Color.Maroon;
            this.dataGrid1.HeaderFont = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.dataGrid1.HeaderForeColor = System.Drawing.Color.LightGoldenrodYellow;
            this.dataGrid1.LinkColor = System.Drawing.Color.Maroon;
            this.dataGrid1.Location = new System.Drawing.Point(507, 84);
            this.dataGrid1.Name = "dataGrid1";
            this.dataGrid1.ParentRowsBackColor = System.Drawing.Color.BurlyWood;
            this.dataGrid1.ParentRowsForeColor = System.Drawing.Color.DarkSlateBlue;
            this.dataGrid1.RowHeadersVisible = false;
            this.dataGrid1.SelectionBackColor = System.Drawing.Color.DarkSlateBlue;
            this.dataGrid1.SelectionForeColor = System.Drawing.Color.GhostWhite;
            this.dataGrid1.Size = new System.Drawing.Size(519, 519);
            this.dataGrid1.TabIndex = 81;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Georgia", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Image = global::databaseC.Properties.Resources.Delete_2;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(346, 344);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(95, 39);
            this.button1.TabIndex = 83;
            this.button1.Text = "&Delete";
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // panelBOTTOM
            // 
            this.panelBOTTOM.BackgroundImage = global::databaseC.Properties.Resources.payroll_03;
            this.panelBOTTOM.Controls.Add(this.picBOTTOM_LEFT);
            this.panelBOTTOM.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelBOTTOM.Location = new System.Drawing.Point(0, 702);
            this.panelBOTTOM.Name = "panelBOTTOM";
            this.panelBOTTOM.Size = new System.Drawing.Size(1028, 44);
            this.panelBOTTOM.TabIndex = 82;
            // 
            // picBOTTOM_LEFT
            // 
            this.picBOTTOM_LEFT.Dock = System.Windows.Forms.DockStyle.Left;
            this.picBOTTOM_LEFT.Image = global::databaseC.Properties.Resources.payroll_03;
            this.picBOTTOM_LEFT.Location = new System.Drawing.Point(0, 0);
            this.picBOTTOM_LEFT.Name = "picBOTTOM_LEFT";
            this.picBOTTOM_LEFT.Size = new System.Drawing.Size(302, 44);
            this.picBOTTOM_LEFT.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picBOTTOM_LEFT.TabIndex = 1;
            this.picBOTTOM_LEFT.TabStop = false;
            // 
            // panelTOP
            // 
            this.panelTOP.BackgroundImage = global::databaseC.Properties.Resources.payroll_03;
            this.panelTOP.Controls.Add(this.label20);
            this.panelTOP.Controls.Add(this.picTOP_LEFT_02);
            this.panelTOP.Controls.Add(this.picTOP_LEFT_01);
            this.panelTOP.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTOP.Location = new System.Drawing.Point(0, 0);
            this.panelTOP.Name = "panelTOP";
            this.panelTOP.Size = new System.Drawing.Size(1028, 78);
            this.panelTOP.TabIndex = 78;
            // 
            // label20
            // 
            this.label20.BackColor = System.Drawing.Color.LightSkyBlue;
            this.label20.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(156, 21);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(870, 26);
            this.label20.TabIndex = 2;
            this.label20.Text = "Stock Return";
            // 
            // picTOP_LEFT_02
            // 
            this.picTOP_LEFT_02.Dock = System.Windows.Forms.DockStyle.Left;
            this.picTOP_LEFT_02.Image = global::databaseC.Properties.Resources.payroll_03;
            this.picTOP_LEFT_02.Location = new System.Drawing.Point(156, 0);
            this.picTOP_LEFT_02.Name = "picTOP_LEFT_02";
            this.picTOP_LEFT_02.Size = new System.Drawing.Size(302, 78);
            this.picTOP_LEFT_02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picTOP_LEFT_02.TabIndex = 1;
            this.picTOP_LEFT_02.TabStop = false;
            // 
            // picTOP_LEFT_01
            // 
            this.picTOP_LEFT_01.Dock = System.Windows.Forms.DockStyle.Left;
            this.picTOP_LEFT_01.Image = global::databaseC.Properties.Resources.payroll_01;
            this.picTOP_LEFT_01.Location = new System.Drawing.Point(0, 0);
            this.picTOP_LEFT_01.Name = "picTOP_LEFT_01";
            this.picTOP_LEFT_01.Size = new System.Drawing.Size(156, 78);
            this.picTOP_LEFT_01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picTOP_LEFT_01.TabIndex = 0;
            this.picTOP_LEFT_01.TabStop = false;
            // 
            // button10
            // 
            this.button10.Font = new System.Drawing.Font("Georgia", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.Image = global::databaseC.Properties.Resources.addon;
            this.button10.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button10.Location = new System.Drawing.Point(394, 264);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(92, 43);
            this.button10.TabIndex = 72;
            this.button10.Text = "&Update";
            this.button10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button7
            // 
            this.button7.Font = new System.Drawing.Font("Georgia", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Image = global::databaseC.Properties.Resources._1;
            this.button7.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button7.Location = new System.Drawing.Point(288, 264);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(87, 43);
            this.button7.TabIndex = 66;
            this.button7.Text = "&Clear";
            this.button7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // Return
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1028, 746);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panelBOTTOM);
            this.Controls.Add(this.dataGrid1);
            this.Controls.Add(this.date);
            this.Controls.Add(this.date123);
            this.Controls.Add(this.panelTOP);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.Purchase);
            this.Controls.Add(this.txtpri);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.txtstock);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.txtbat);
            this.Controls.Add(this.txtmfc);
            this.Controls.Add(this.txtmed);
            this.Controls.Add(this.txtin);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Return";
            this.Text = "Form4";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Return_KeyDown);
            this.Load += new System.EventHandler(this.Form4_Load);
            this.Purchase.ResumeLayout(false);
            this.Purchase.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).EndInit();
            this.panelBOTTOM.ResumeLayout(false);
            this.panelBOTTOM.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBOTTOM_LEFT)).EndInit();
            this.panelTOP.ResumeLayout(false);
            this.panelTOP.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picTOP_LEFT_02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picTOP_LEFT_01)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.GroupBox Purchase;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtqty;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txttotamt;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtuni;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txttaxper;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtpri;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txttaxamt;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.TextBox txtstock;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtbat;
        private System.Windows.Forms.TextBox txtmfc;
        private System.Windows.Forms.TextBox txtmed;
        private System.Windows.Forms.TextBox txtin;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panelTOP;
        internal System.Windows.Forms.Label label20;
        private System.Windows.Forms.PictureBox picTOP_LEFT_02;
        private System.Windows.Forms.PictureBox picTOP_LEFT_01;
        private System.Windows.Forms.Label date123;
        private System.Windows.Forms.Label date;
        private System.Windows.Forms.DataGrid dataGrid1;
        private System.Windows.Forms.Panel panelBOTTOM;
        private System.Windows.Forms.PictureBox picBOTTOM_LEFT;
        private System.Windows.Forms.Button button1;
    }
}